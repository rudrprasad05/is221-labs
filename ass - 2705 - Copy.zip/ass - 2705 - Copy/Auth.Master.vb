﻿Imports Microsoft.VisualBasic

Public Class Auth

    Inherits System.Web.UI.MasterPage

   
End Class
