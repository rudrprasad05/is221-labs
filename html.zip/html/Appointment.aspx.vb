﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub clearbtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles clearbtn.Click
        txtpname.Text = ""
        radfemale.Checked = False
        radmale.Checked = False
        txtponame.Text = ""
        txtpnumber.Text = ""
        txtpage.Text = ""
        txtaddress.Text = ""
        txtemail.Text = ""
        radyes.Checked = False
        radno.Checked = False
        txtcondition.Text = ""
        rad1.Checked = False
        rad2.Checked = False
        rad3.Checked = False
        rad4.Checked = False
        rad5.Checked = False
        rad6.Checked = False
        lbldisplay.Text = ""

    End Sub

    Protected Sub submitbtn_Click(ByVal sender As Object, ByVal e As EventArgs) Handles submitbtn.Click

        lbldisplay.Text = "The following details have been saved to our database <br />"
        lbldisplay.Text = lbldisplay.Text & "Your pet's full name is: " & txtpname.Text & "<br />"

        If radfemale.Checked = True Then
            lbldisplay.Text = "The gender of your pet is Female" & "<br />"

        ElseIf radmale.Checked = True Then
            lbldisplay.Text = "The gender of your pet is Male" & "<br />"

        End If

        lbldisplay.Text = lbldisplay.Text & "Your pet's owner's name is: " & txtponame.Text & "<br />"
        lbldisplay.Text &= "Your phone is: " & txtpnumber.Text & "<br />"
        lbldisplay.Text &= "Your pet's age is: " & txtpage.Text & "<br />"
        lbldisplay.Text &= "Your address is: " & txtaddress.Text & "<br />"
        lbldisplay.Text &= "Your address is: " & txtemail.Text & "<br />"

        If radyes.Checked = True Then
            lbldisplay.Text = txtcondition.Text & "<br />"

        ElseIf radno.Checked = True Then
            lbldisplay.Text = "" & "<br />"

        End If


        If rad1.Checked = True Then
            lbldisplay.Text = "The appointment time is: 1:00pm" & "<br />"

        ElseIf rad2.Checked = True Then
            lbldisplay.Text = "The appointment time is: 2:00pm" & "<br />"

        ElseIf rad3.Checked = True Then
            lbldisplay.Text = "The appointment time is: 3:00pm" & "<br />"

        ElseIf rad4.Checked = True Then
            lbldisplay.Text = "The appointment time is: 6:00am" & "<br />"

        ElseIf rad5.Checked = True Then
            lbldisplay.Text = "The appointment time is: 7:00am" & "<br />"

        ElseIf rad6.Checked = True Then
            lbldisplay.Text = "The appointment time is: 8:00am" & "<br />"

        End If

    End Sub

End Class
