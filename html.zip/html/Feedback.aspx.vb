﻿Public Class Feedback
    Inherits System.Web.UI.Page

    Protected Sub btnclear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles clearbtn.Click

        txtfname.Text = ""
        txtlname.Text = ""
        txtpnumber.Text = ""
        txtemail.Text = ""
        txtfeedback.Text = ""
        lbldisplay.Text = ""


    End Sub

    Protected Sub btnsend_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnsend.Click

        lbldisplay.Text = "The following details have been saved to our database <br />"
        lbldisplay.Text = lbldisplay.Text & "Your first name is: " & txtfname.Text & "<br />"
        lbldisplay.Text = lbldisplay.Text & "Your last name is: " & txtlname.Text & "<br />"
        lbldisplay.Text &= "Your phone is: " & txtpnumber.Text & "<br />"
        lbldisplay.Text &= "You email is: " & txtemail.Text & "<br />"
        lbldisplay.Text &= "You feedback is: " & txtfeedback.Text & "<br />"

        adsfeedback.InsertParameters("First Name").DefaultValue = txtfname.Text
        adsfeedback.InsertParameters("Last Name").DefaultValue = txtlname.Text
        adsfeedback.InsertParameters("Phone Number").DefaultValue = txtpnumber.Text
        adsfeedback.InsertParameters("Email").DefaultValue = txtemail.Text
        adsfeedback.InsertParameters("Feedback").DefaultValue = txtfeedback.Text

    End Sub
End Class