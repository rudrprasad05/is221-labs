﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles clearbtn.Click
        txtname.Text = ""
        txtusername.Text = ""
        txtpassword.Text = ""
        txtemail.Text = ""
        lblverify.Text = ""

    End Sub

    Protected Sub registerbtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles registerbtn.Click
        lblverify.Text = "The following details have been saved to our database <br />"
        lblverify.Text = lblverify.Text & "Your name: " & txtname.Text & "<br />"
        lblverify.Text &= "Your new username is: " & txtusername.Text & "<br />"
        lblverify.Text &= "Your password: " & txtpassword.Text & "<br />"
        lblverify.Text &= "You email is: " & txtemail.Text & "<br />"


        adsRegister.InsertParameters("Name").DefaultValue = txtname.Text
        adsRegister.InsertParameters("Username").DefaultValue = txtusername.Text
        adsRegister.InsertParameters("Password").DefaultValue = txtpassword.Text
        adsRegister.InsertParameters("Email").DefaultValue = txtemail.Text

    End Sub
End Class
